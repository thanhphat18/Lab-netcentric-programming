package main

import (
    "database/sql"
    "fmt"
    "log"
    "net/http"
    "regexp"
    "strconv"
    "time"

    "github.com/gin-gonic/gin"
    _ "github.com/mattn/go-sqlite3"
)

// ─────────────────────────────────────────
// STRUCTS
// ─────────────────────────────────────────

// Book is the core data model.
// binding tags tell Gin what to validate automatically when ShouldBindJSON() is called.
// "required"     → field must be present and non-zero
// "min=3"        → string must be at least 3 chars
// "min=0.01"     → float must be >= 0.01
// "max=1000"     → float must be <= 1000
// "gte=0"        → int must be >= 0  (gte = greater than or equal)
type Book struct {
    ID            int     `json:"id"`
    Title         string  `json:"title"         binding:"required,min=3"`
    Author        string  `json:"author"         binding:"required"`
    AuthorID      int     `json:"author_id"`
    ISBN          string  `json:"isbn"           binding:"required"`
    Price         float64 `json:"price"          binding:"required,min=0.01,max=1000"`
    Stock         int     `json:"stock"          binding:"gte=0"`
    PublishedYear int     `json:"published_year"`
    Description   string  `json:"description"`
    CreatedAt     string  `json:"created_at"`
}

// Author struct (same as Task 3)
type Author struct {
    ID        int    `json:"id"`
    Name      string `json:"name"       binding:"required"`
    Bio       string `json:"bio"`
    BirthYear int    `json:"birth_year"`
    Country   string `json:"country"`
    CreatedAt string `json:"created_at"`
}

// BookWithAuthor combines book data + author name from a JOIN query
type BookWithAuthor struct {
    ID            int     `json:"id"`
    Title         string  `json:"title"`
    AuthorID      int     `json:"author_id"`
    AuthorName    string  `json:"author_name"`
    ISBN          string  `json:"isbn"`
    Price         float64 `json:"price"`
    Stock         int     `json:"stock"`
    PublishedYear int     `json:"published_year"`
    Description   string  `json:"description"`
}

// PaginationMeta holds all the page-related metadata the client needs
// to render navigation controls (Next button, page numbers, etc.)
type PaginationMeta struct {
    Page       int  `json:"page"`
    Limit      int  `json:"limit"`
    Total      int  `json:"total"`       // total rows in DB matching the query
    TotalPages int  `json:"total_pages"`
    HasNext    bool `json:"has_next"`
    HasPrev    bool `json:"has_prev"`
}

// PaginatedBooksResponse wraps both the data and the metadata into one JSON object
type PaginatedBooksResponse struct {
    Books      []BookWithAuthor `json:"books"`
    Pagination PaginationMeta   `json:"pagination"`
}

// ─────────────────────────────────────────
// GLOBAL DATABASE CONNECTION
// ─────────────────────────────────────────
// var at package level means all handler functions share this one connection.
// This is safe because database/sql manages a connection pool internally.
var db *sql.DB

// ─────────────────────────────────────────
// DATABASE INIT
// ─────────────────────────────────────────

func initDB() error {
    var err error
    // sql.Open does NOT actually connect yet — it just prepares the driver.
    // The real connection happens on the first query.
    db, err = sql.Open("sqlite3", "./bookstore.db")
    if err != nil {
        return err
    }

    // We verify the connection is actually alive with Ping()
    if err = db.Ping(); err != nil {
        return err
    }

    createTableSQL := `
    CREATE TABLE IF NOT EXISTS authors (
        id          INTEGER PRIMARY KEY AUTOINCREMENT,
        name        TEXT NOT NULL UNIQUE,
        bio         TEXT,
        birth_year  INTEGER,
        country     TEXT,
        created_at  DATETIME DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS books (
        id             INTEGER PRIMARY KEY AUTOINCREMENT,
        title          TEXT NOT NULL,
        author         TEXT,
        author_id      INTEGER,
        isbn           TEXT UNIQUE,
        price          REAL NOT NULL CHECK(price > 0),
        stock          INTEGER DEFAULT 0,
        published_year INTEGER,
        description    TEXT,
        created_at     DATETIME DEFAULT CURRENT_TIMESTAMP
    );`

    _, err = db.Exec(createTableSQL)
    return err
}

func seedData() {
    var count int
    db.QueryRow("SELECT COUNT(*) FROM books").Scan(&count)
    if count > 0 {
        return
    }

    // Insert sample authors first
    authors := []struct{ name, bio, country string; year int }{
        {"Alan Donovan", "Go team member at Google", "USA", 0},
        {"Robert C. Martin", "Software engineer and author", "USA", 1952},
        {"Gang of Four", "Design patterns pioneers", "Various", 0},
        {"Jon Bodner", "Go expert and educator", "USA", 0},
        {"Andrew Tanenbaum", "Computer science professor", "Netherlands", 1944},
    }
    for _, a := range authors {
        db.Exec("INSERT OR IGNORE INTO authors (name, bio, country, birth_year) VALUES (?,?,?,?)",
            a.name, a.bio, a.country, a.year)
    }

    // Seed books linked to authors
    books := []struct {
        title, author, isbn, desc string
        price                     float64
        stock, year, authorID     int
    }{
        {"The Go Programming Language", "Alan Donovan", "9780134190440", "Complete Go guide", 39.99, 15, 2015, 1},
        {"Clean Code", "Robert C. Martin", "9780132350884", "Writing readable code", 42.50, 20, 2008, 2},
        {"Design Patterns", "Gang of Four", "9780201633610", "Classic patterns book", 54.99, 8, 1994, 3},
        {"Learning Go", "Jon Bodner", "9781492077213", "Idiomatic Go programming", 44.99, 12, 2021, 4},
        {"Modern Operating Systems", "Andrew Tanenbaum", "9780137618880", "OS fundamentals", 89.99, 5, 2014, 5},
        {"Clean Architecture", "Robert C. Martin", "9780134494166", "Architecture principles", 39.99, 18, 2017, 2},
        {"Go in Action", "Alan Donovan", "9781617291784", "Practical Go examples", 35.99, 10, 2015, 1},
        {"Refactoring", "Robert C. Martin", "9780134757599", "Improving existing code", 47.99, 7, 2018, 2},
        {"The Pragmatic Programmer", "Andrew Tanenbaum", "9780201616224", "Career advice for devs", 49.99, 14, 1999, 5},
        {"Code Complete", "Gang of Four", "9780735619678", "Software construction", 52.99, 9, 2004, 3},
        {"Concurrency in Go", "Jon Bodner", "9781491941195", "Go concurrency patterns", 36.99, 11, 2017, 4},
        {"Computer Networks", "Andrew Tanenbaum", "9780132126953", "Networking fundamentals", 79.99, 6, 2010, 5},
    }
    for _, b := range books {
        db.Exec(`INSERT OR IGNORE INTO books
            (title, author, author_id, isbn, price, stock, published_year, description)
            VALUES (?,?,?,?,?,?,?,?)`,
            b.title, b.author, b.authorID, b.isbn, b.price, b.stock, b.year, b.desc)
    }
    fmt.Println("Seeded sample data")
}

// ─────────────────────────────────────────
// CUSTOM VALIDATION FUNCTIONS
// ─────────────────────────────────────────

// validateISBN checks that the ISBN is either 10 or 13 digits (hyphens stripped first).
// Real-world: ISBN-10 was used before 2007, ISBN-13 after. Both are still valid.
func validateISBN(isbn string) error {
    // regexp.MustCompile compiles the regex pattern. "-" means the literal hyphen character.
    // ReplaceAllString replaces every hyphen with nothing — stripping them.
    // Example: "978-0-13-419044-0" → "9780134190440"
    clean := regexp.MustCompile(`-`).ReplaceAllString(isbn, "")

    if len(clean) != 10 && len(clean) != 13 {
        return fmt.Errorf("ISBN must be 10 or 13 digits, got %d", len(clean))
    }

    // ^\d+$ means: from start (^) to end ($), only digit characters (\d)
    if !regexp.MustCompile(`^\d+$`).MatchString(clean) {
        return fmt.Errorf("ISBN must contain only digits and hyphens")
    }
    return nil
}

// validatePublishedYear checks the year is in a sensible range.
// time.Now().Year() gets the current year at runtime — no hardcoding needed.
func validatePublishedYear(year int) error {
    if year == 0 {
        return nil // optional field — 0 means not provided
    }
    currentYear := time.Now().Year()
    if year < 1800 || year > currentYear {
        return fmt.Errorf("published year must be between 1800 and %d, got %d", currentYear, year)
    }
    return nil
}

// parseIntQuery safely reads an integer query parameter.
// c.Query("page") always returns a string (or "").
// strconv.Atoi converts "1" → 1. If it fails, we use the defaultValue.
func parseIntQuery(c *gin.Context, key string, defaultValue int) int {
    raw := c.Query(key)
    if raw == "" {
        return defaultValue
    }
    val, err := strconv.Atoi(raw)
    if err != nil {
        return defaultValue
    }
    return val
}

// ─────────────────────────────────────────
// HANDLER: GET /books  (with pagination)
// ─────────────────────────────────────────

func getBooksPaginated(c *gin.Context) {
    // Step 1: Read pagination parameters from query string
    // URL example: GET /books?page=2&limit=5
    page  := parseIntQuery(c, "page",  1)
    limit := parseIntQuery(c, "limit", 10)

    // Step 2: Clamp values to safe ranges
    if page < 1 {
        page = 1
    }
    if limit < 1 || limit > 100 {
        limit = 10
    }

    // Step 3: Calculate OFFSET
    // Page 1 → offset 0  (skip nothing)
    // Page 2 → offset 10 (skip the first 10)
    // Page 3 → offset 20 (skip the first 20)
    offset := (page - 1) * limit

    // Step 4: Count total rows FIRST (needed for metadata)
    // We count separately so we know total_pages without fetching everything.
    var total int
    err := db.QueryRow("SELECT COUNT(*) FROM books").Scan(&total)
    if err != nil {
        c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to count books"})
        return
    }

    // Step 5: Fetch exactly `limit` rows starting at `offset`
    // LEFT JOIN brings in the author name — if author_id is NULL, author_name will be empty string
    rows, err := db.Query(`
        SELECT b.id, b.title, COALESCE(b.author_id, 0), COALESCE(a.name, b.author),
               b.isbn, b.price, b.stock, COALESCE(b.published_year, 0), COALESCE(b.description, '')
        FROM books b
        LEFT JOIN authors a ON b.author_id = a.id
        ORDER BY b.id
        LIMIT ? OFFSET ?`, limit, offset)
    if err != nil {
        c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to fetch books"})
        return
    }
    defer rows.Close()

    books := []BookWithAuthor{}
    for rows.Next() {
        var b BookWithAuthor
        // Scan must list variables in the SAME ORDER as the SELECT columns above
        rows.Scan(&b.ID, &b.Title, &b.AuthorID, &b.AuthorName,
            &b.ISBN, &b.Price, &b.Stock, &b.PublishedYear, &b.Description)
        books = append(books, b)
    }

    // Step 6: Calculate pagination metadata
    // Ceiling division: (25 + 10 - 1) / 10 = 34/10 = 3 pages
    // This avoids floating point: no need for math.Ceil()
    totalPages := (total + limit - 1) / limit

    pagination := PaginationMeta{
        Page:       page,
        Limit:      limit,
        Total:      total,
        TotalPages: totalPages,
        HasNext:    page < totalPages,
        HasPrev:    page > 1,
    }

    // Step 7: Return combined response
    c.JSON(http.StatusOK, PaginatedBooksResponse{
        Books:      books,
        Pagination: pagination,
    })
}

// ─────────────────────────────────────────
// HANDLER: POST /books  (with full validation)
// ─────────────────────────────────────────

func createBookEnhanced(c *gin.Context) {
    var book Book

    // Stage 1: Gin's built-in binding validation
    // This checks all the `binding:"..."` tags on the struct automatically.
    // If any fail, ShouldBindJSON returns a descriptive error.
    if err := c.ShouldBindJSON(&book); err != nil {
        c.JSON(http.StatusBadRequest, gin.H{
            "error":   "Validation failed",
            "details": err.Error(),
        })
        return
    }

    // Stage 2: Custom ISBN validation (Gin's binding tags can't check digit count)
    if err := validateISBN(book.ISBN); err != nil {
        c.JSON(http.StatusBadRequest, gin.H{
            "error":   "Invalid ISBN",
            "details": err.Error(),
        })
        return
    }

    // Stage 3: Custom year validation
    if err := validatePublishedYear(book.PublishedYear); err != nil {
        c.JSON(http.StatusBadRequest, gin.H{
            "error":   "Invalid published year",
            "details": err.Error(),
        })
        return
    }

    // Stage 4: If author_id provided, check that author actually exists in DB
    if book.AuthorID > 0 {
        var exists bool
        // EXISTS(SELECT 1 ...) is faster than COUNT(*) — stops as soon as one row is found
        db.QueryRow("SELECT EXISTS(SELECT 1 FROM authors WHERE id = ?)", book.AuthorID).Scan(&exists)
        if !exists {
            c.JSON(http.StatusBadRequest, gin.H{
                "error":   "Author not found",
                "details": fmt.Sprintf("No author with id %d exists", book.AuthorID),
            })
            return
        }
        // Look up the author name so we can store it in the author column too
        db.QueryRow("SELECT name FROM authors WHERE id = ?", book.AuthorID).Scan(&book.Author)
    }

    // Stage 5: All validation passed — insert into database
    result, err := db.Exec(`
        INSERT INTO books (title, author, author_id, isbn, price, stock, published_year, description)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
        book.Title, book.Author, book.AuthorID, book.ISBN,
        book.Price, book.Stock, book.PublishedYear, book.Description)
    if err != nil {
        c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to create book"})
        return
    }

    id, _ := result.LastInsertId()
    book.ID = int(id)

    // 201 Created = the standard status code for a successful resource creation
    c.JSON(http.StatusCreated, book)
}

// ─────────────────────────────────────────
// CARRY-FORWARD HANDLERS FROM TASK 1-3
// ─────────────────────────────────────────

func getBook(c *gin.Context) {
    id := c.Param("id")
    var b BookWithAuthor
    err := db.QueryRow(`
        SELECT b.id, b.title, COALESCE(b.author_id,0), COALESCE(a.name, b.author),
               b.isbn, b.price, b.stock, COALESCE(b.published_year,0), COALESCE(b.description,'')
        FROM books b LEFT JOIN authors a ON b.author_id = a.id
        WHERE b.id = ?`, id).
        Scan(&b.ID, &b.Title, &b.AuthorID, &b.AuthorName,
            &b.ISBN, &b.Price, &b.Stock, &b.PublishedYear, &b.Description)
    if err == sql.ErrNoRows {
        c.JSON(http.StatusNotFound, gin.H{"error": "Book not found"})
        return
    } else if err != nil {
        c.JSON(http.StatusInternalServerError, gin.H{"error": "Database error"})
        return
    }
    c.JSON(http.StatusOK, b)
}

func updateBook(c *gin.Context) {
    id := c.Param("id")
    var book Book
    if err := c.ShouldBindJSON(&book); err != nil {
        c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
        return
    }
    result, err := db.Exec(`
        UPDATE books SET title=?, author=?, isbn=?, price=?, stock=?, published_year=?, description=?
        WHERE id=?`,
        book.Title, book.Author, book.ISBN, book.Price,
        book.Stock, book.PublishedYear, book.Description, id)
    if err != nil {
        c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to update"})
        return
    }
    if n, _ := result.RowsAffected(); n == 0 {
        c.JSON(http.StatusNotFound, gin.H{"error": "Book not found"})
        return
    }
    book.ID, _ = strconv.Atoi(id)
    c.JSON(http.StatusOK, book)
}

func deleteBook(c *gin.Context) {
    id := c.Param("id")
    result, err := db.Exec("DELETE FROM books WHERE id = ?", id)
    if err != nil {
        c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to delete"})
        return
    }
    if n, _ := result.RowsAffected(); n == 0 {
        c.JSON(http.StatusNotFound, gin.H{"error": "Book not found"})
        return
    }
    c.JSON(http.StatusOK, gin.H{"message": "Book deleted"})
}

func searchBooks(c *gin.Context) {
    q := c.Query("q")
    if q == "" {
        c.JSON(http.StatusBadRequest, gin.H{"error": "Search query ?q= required"})
        return
    }
    pattern := "%" + q + "%"
    rows, err := db.Query(`
        SELECT b.id, b.title, COALESCE(b.author_id,0), COALESCE(a.name, b.author),
               b.isbn, b.price, b.stock, COALESCE(b.published_year,0), COALESCE(b.description,'')
        FROM books b LEFT JOIN authors a ON b.author_id = a.id
        WHERE b.title LIKE ? OR b.author LIKE ?`, pattern, pattern)
    if err != nil {
        c.JSON(http.StatusInternalServerError, gin.H{"error": "Search failed"})
        return
    }
    defer rows.Close()
    books := []BookWithAuthor{}
    for rows.Next() {
        var b BookWithAuthor
        rows.Scan(&b.ID, &b.Title, &b.AuthorID, &b.AuthorName,
            &b.ISBN, &b.Price, &b.Stock, &b.PublishedYear, &b.Description)
        books = append(books, b)
    }
    c.JSON(http.StatusOK, gin.H{"books": books, "count": len(books), "query": q})
}

func filterBooks(c *gin.Context) {
    minPrice := c.Query("min_price")
    maxPrice := c.Query("max_price")
    author   := c.Query("author")
    year     := c.Query("year")

    // Dynamic query building: start with always-true condition,
    // then append clauses only for parameters that were actually provided.
    // This avoids building broken SQL like "WHERE AND price > 0"
    query  := `SELECT b.id, b.title, COALESCE(b.author_id,0), COALESCE(a.name,b.author),
                      b.isbn, b.price, b.stock, COALESCE(b.published_year,0), COALESCE(b.description,'')
               FROM books b LEFT JOIN authors a ON b.author_id = a.id WHERE 1=1`
    args   := []interface{}{}

    if minPrice != "" {
        query += " AND b.price >= ?"
        args = append(args, minPrice)
    }
    if maxPrice != "" {
        query += " AND b.price <= ?"
        args = append(args, maxPrice)
    }
    if author != "" {
        query += " AND b.author LIKE ?"
        args = append(args, "%"+author+"%")
    }
    if year != "" {
        query += " AND b.published_year = ?"
        args = append(args, year)
    }

    rows, err := db.Query(query, args...)
    if err != nil {
        c.JSON(http.StatusInternalServerError, gin.H{"error": "Filter failed"})
        return
    }
    defer rows.Close()
    books := []BookWithAuthor{}
    for rows.Next() {
        var b BookWithAuthor
        rows.Scan(&b.ID, &b.Title, &b.AuthorID, &b.AuthorName,
            &b.ISBN, &b.Price, &b.Stock, &b.PublishedYear, &b.Description)
        books = append(books, b)
    }
    c.JSON(http.StatusOK, gin.H{"books": books, "count": len(books)})
}

// ─────────────────────────────────────────
// MAIN — wire everything together
// ─────────────────────────────────────────

func main() {
    if err := initDB(); err != nil {
        log.Fatal("DB init failed:", err)
    }
    defer db.Close()
    seedData()

    router := gin.Default()

    // Books — paginated list + full validation on create
    router.GET("/books",        getBooksPaginated)   // Task 4: now paginated
    router.GET("/books/search", searchBooks)
    router.GET("/books/filter", filterBooks)
    router.GET("/books/:id",    getBook)
    router.POST("/books",       createBookEnhanced)  // Task 4: full validation
    router.PUT("/books/:id",    updateBook)
    router.DELETE("/books/:id", deleteBook)

    fmt.Println("Server running on :8080")
    router.Run(":8080")
}