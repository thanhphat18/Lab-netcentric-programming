package main

import (
	"database/sql"
	"log"
	"net/http"
	"strings"

	"github.com/gin-gonic/gin"
	_ "github.com/mattn/go-sqlite3"
)

type Author struct {
	ID        int    `json:"id"`
	Name      string `json:"name" binding:"required"`
	Bio       string `json:"bio"`
	BirthYear int    `json:"birth_year"`
	Country   string `json:"country"`
	CreatedAt string `json:"created_at"`
}

type Book struct {
	ID            int     `json:"id"`
	Title         string  `json:"title" binding:"required"`
	AuthorID      int     `json:"author_id" binding:"required"`
	ISBN          string  `json:"isbn"`
	Price         float64 `json:"price" binding:"required,gt=0"`
	Stock         int     `json:"stock" binding:"gte=0"`
	PublishedYear int     `json:"published_year"`
	Description   string  `json:"description"`
	CreatedAt     string  `json:"created_at"`
}

type BookWithAuthor struct {
	ID            int     `json:"id"`
	Title         string  `json:"title"`
	AuthorID      int     `json:"author_id"`
	AuthorName    string  `json:"author_name"`
	ISBN          string  `json:"isbn"`
	Price         float64 `json:"price"`
	Stock         int     `json:"stock"`
	PublishedYear int     `json:"published_year"`
	Description   string  `json:"description"`
	CreatedAt     string  `json:"created_at"`
}

var db *sql.DB

func initDB() error {
	var err error
	db, err = sql.Open("sqlite3", "./bookstore.db")
	if err != nil {
		return err
	}

	createAuthorsSQL := `
	CREATE TABLE IF NOT EXISTS authors (
		id INTEGER PRIMARY KEY AUTOINCREMENT,
		name TEXT NOT NULL UNIQUE,
		bio TEXT,
		birth_year INTEGER,
		country TEXT,
		created_at DATETIME DEFAULT CURRENT_TIMESTAMP
	);`

	_, err = db.Exec(createAuthorsSQL)
	if err != nil {
		return err
	}

	createBooksSQL := `
	CREATE TABLE IF NOT EXISTS books (
		id INTEGER PRIMARY KEY AUTOINCREMENT,
		title TEXT NOT NULL,
		author_id INTEGER NOT NULL,
		isbn TEXT UNIQUE,
		price REAL NOT NULL CHECK(price > 0),
		stock INTEGER DEFAULT 0,
		published_year INTEGER,
		description TEXT,
		created_at DATETIME DEFAULT CURRENT_TIMESTAMP
	);`

	_, err = db.Exec(createBooksSQL)
	return err
}

func seedAuthors() {
	var count int
	err := db.QueryRow("SELECT COUNT(*) FROM authors").Scan(&count)
	if err != nil || count > 0 {
		return
	}

	authors := []Author{
		{Name: "Robert C. Martin", Bio: "Software engineer and author", BirthYear: 1952, Country: "USA"},
		{Name: "Gang of Four", Bio: "Design patterns pioneers", BirthYear: 0, Country: "Various"},
		{Name: "Alan Donovan", Bio: "Go team member and author", BirthYear: 0, Country: "USA"},
		{Name: "Andrew Hunt", Bio: "Author of The Pragmatic Programmer", BirthYear: 1964, Country: "USA"},
		{Name: "Steve McConnell", Bio: "Software engineering author", BirthYear: 1962, Country: "USA"},
		{Name: "Jon Bodner", Bio: "Go programming author", BirthYear: 0, Country: "USA"},
	}

	for _, author := range authors {
		_, err := db.Exec(
			"INSERT INTO authors (name, bio, birth_year, country) VALUES (?, ?, ?, ?)",
			author.Name, author.Bio, author.BirthYear, author.Country,
		)
		if err != nil {
			log.Printf("warning: failed to seed author %q: %v", author.Name, err)
		}
	}
}

func getAuthorIDByName(name string) int {
	var id int
	err := db.QueryRow("SELECT id FROM authors WHERE name = ?", name).Scan(&id)
	if err != nil {
		return 0
	}
	return id
}

func seedBooks() {
	var count int
	err := db.QueryRow("SELECT COUNT(*) FROM books").Scan(&count)
	if err != nil || count > 0 {
		return
	}

	books := []Book{
		{
			Title:         "The Go Programming Language",
			AuthorID:      getAuthorIDByName("Alan Donovan"),
			ISBN:          "978-0134190440",
			Price:         39.99,
			Stock:         15,
			PublishedYear: 2015,
			Description:   "Complete guide to Go",
		},
		{
			Title:         "Clean Code",
			AuthorID:      getAuthorIDByName("Robert C. Martin"),
			ISBN:          "978-0132350884",
			Price:         42.50,
			Stock:         20,
			PublishedYear: 2008,
			Description:   "Handbook of Agile Software Craftsmanship",
		},
		{
			Title:         "Design Patterns",
			AuthorID:      getAuthorIDByName("Gang of Four"),
			ISBN:          "978-0201633610",
			Price:         54.99,
			Stock:         8,
			PublishedYear: 1994,
			Description:   "Elements of Reusable Object-Oriented Software",
		},
		{
			Title:         "The Pragmatic Programmer",
			AuthorID:      getAuthorIDByName("Andrew Hunt"),
			ISBN:          "978-0135957059",
			Price:         47.99,
			Stock:         12,
			PublishedYear: 2019,
			Description:   "Journey to mastery",
		},
		{
			Title:         "Code Complete",
			AuthorID:      getAuthorIDByName("Steve McConnell"),
			ISBN:          "978-0735619678",
			Price:         49.99,
			Stock:         10,
			PublishedYear: 2004,
			Description:   "Practical handbook of software construction",
		},
		{
			Title:         "Learning Go",
			AuthorID:      getAuthorIDByName("Jon Bodner"),
			ISBN:          "978-1492077213",
			Price:         44.99,
			Stock:         14,
			PublishedYear: 2021,
			Description:   "Idiomatic Go for real-world programming",
		},
	}

	for _, book := range books {
		_, err := db.Exec(
			`INSERT INTO books (title, author_id, isbn, price, stock, published_year, description)
			 VALUES (?, ?, ?, ?, ?, ?, ?)`,
			book.Title, book.AuthorID, book.ISBN, book.Price, book.Stock, book.PublishedYear, book.Description,
		)
		if err != nil {
			log.Printf("warning: failed to seed book %q: %v", book.Title, err)
		}
	}
}

func authorExists(authorID int) bool {
	var exists bool
	err := db.QueryRow("SELECT EXISTS(SELECT 1 FROM authors WHERE id = ?)", authorID).Scan(&exists)
	return err == nil && exists
}

func scanBooksWithAuthors(rows *sql.Rows) ([]BookWithAuthor, error) {
	defer rows.Close()

	books := []BookWithAuthor{}
	for rows.Next() {
		var book BookWithAuthor
		err := rows.Scan(
			&book.ID,
			&book.Title,
			&book.AuthorID,
			&book.AuthorName,
			&book.ISBN,
			&book.Price,
			&book.Stock,
			&book.PublishedYear,
			&book.Description,
			&book.CreatedAt,
		)
		if err != nil {
			return nil, err
		}
		books = append(books, book)
	}
	return books, nil
}

func getBooks(c *gin.Context) {
	sortBy := c.DefaultQuery("sort", "id")
	minPrice := c.Query("min_price")
	maxPrice := c.Query("max_price")
	year := c.Query("year")
	author := c.Query("author")

	validSorts := map[string]string{
		"price_asc":  "b.price ASC",
		"price_desc": "b.price DESC",
		"title":      "b.title ASC",
		"year_desc":  "b.published_year DESC",
		"id":         "b.id ASC",
	}

	orderBy, ok := validSorts[sortBy]
	if !ok {
		orderBy = "b.id ASC"
	}

	queryBuilder := `
		SELECT b.id, b.title, b.author_id, a.name as author_name,
		       b.isbn, b.price, b.stock, b.published_year, b.description, b.created_at
		FROM books b
		LEFT JOIN authors a ON b.author_id = a.id
		WHERE 1=1
	`
	args := []interface{}{}

	if minPrice != "" {
		queryBuilder += " AND b.price >= ?"
		args = append(args, minPrice)
	}
	if maxPrice != "" {
		queryBuilder += " AND b.price <= ?"
		args = append(args, maxPrice)
	}
	if year != "" {
		queryBuilder += " AND b.published_year = ?"
		args = append(args, year)
	}
	if author != "" {
		queryBuilder += " AND LOWER(a.name) LIKE ?"
		args = append(args, "%"+strings.ToLower(author)+"%")
	}

	queryBuilder += " ORDER BY " + orderBy

	rows, err := db.Query(queryBuilder, args...)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to fetch books"})
		return
	}

	books, err := scanBooksWithAuthors(rows)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to read books"})
		return
	}

	c.JSON(http.StatusOK, gin.H{
		"books": books,
		"count": len(books),
	})
}

func getBook(c *gin.Context) {
	id := c.Param("id")

	var book BookWithAuthor
	err := db.QueryRow(`
		SELECT b.id, b.title, b.author_id, a.name as author_name,
		       b.isbn, b.price, b.stock, b.published_year, b.description, b.created_at
		FROM books b
		LEFT JOIN authors a ON b.author_id = a.id
		WHERE b.id = ?
	`, id).Scan(
		&book.ID,
		&book.Title,
		&book.AuthorID,
		&book.AuthorName,
		&book.ISBN,
		&book.Price,
		&book.Stock,
		&book.PublishedYear,
		&book.Description,
		&book.CreatedAt,
	)

	if err == sql.ErrNoRows {
		c.JSON(http.StatusNotFound, gin.H{"error": "Book not found"})
		return
	}
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Database error"})
		return
	}

	c.JSON(http.StatusOK, book)
}

func createBook(c *gin.Context) {
	var book Book
	if err := c.ShouldBindJSON(&book); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{
			"error":   "Invalid request data",
			"details": err.Error(),
		})
		return
	}

	if !authorExists(book.AuthorID) {
		c.JSON(http.StatusBadRequest, gin.H{
			"error": "Author not found",
		})
		return
	}

	result, err := db.Exec(`
		INSERT INTO books (title, author_id, isbn, price, stock, published_year, description)
		VALUES (?, ?, ?, ?, ?, ?, ?)
	`, book.Title, book.AuthorID, book.ISBN, book.Price, book.Stock, book.PublishedYear, book.Description)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to create book"})
		return
	}

	id, _ := result.LastInsertId()

	var created BookWithAuthor
	err = db.QueryRow(`
		SELECT b.id, b.title, b.author_id, a.name as author_name,
		       b.isbn, b.price, b.stock, b.published_year, b.description, b.created_at
		FROM books b
		LEFT JOIN authors a ON b.author_id = a.id
		WHERE b.id = ?
	`, id).Scan(
		&created.ID,
		&created.Title,
		&created.AuthorID,
		&created.AuthorName,
		&created.ISBN,
		&created.Price,
		&created.Stock,
		&created.PublishedYear,
		&created.Description,
		&created.CreatedAt,
	)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to fetch created book"})
		return
	}

	c.JSON(http.StatusCreated, created)
}

func updateBook(c *gin.Context) {
	id := c.Param("id")

	var book Book
	if err := c.ShouldBindJSON(&book); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{
			"error":   "Invalid request data",
			"details": err.Error(),
		})
		return
	}

	if !authorExists(book.AuthorID) {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Author not found"})
		return
	}

	result, err := db.Exec(`
		UPDATE books
		SET title = ?, author_id = ?, isbn = ?, price = ?, stock = ?, published_year = ?, description = ?
		WHERE id = ?
	`, book.Title, book.AuthorID, book.ISBN, book.Price, book.Stock, book.PublishedYear, book.Description, id)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to update book"})
		return
	}

	rowsAffected, _ := result.RowsAffected()
	if rowsAffected == 0 {
		c.JSON(http.StatusNotFound, gin.H{"error": "Book not found"})
		return
	}

	getBook(c)
}

func deleteBook(c *gin.Context) {
	id := c.Param("id")

	result, err := db.Exec("DELETE FROM books WHERE id = ?", id)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to delete book"})
		return
	}

	rowsAffected, _ := result.RowsAffected()
	if rowsAffected == 0 {
		c.JSON(http.StatusNotFound, gin.H{"error": "Book not found"})
		return
	}

	c.JSON(http.StatusOK, gin.H{"message": "Book deleted successfully"})
}

func searchBooks(c *gin.Context) {
	queryText := strings.TrimSpace(c.Query("q"))
	if queryText == "" {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Search query required"})
		return
	}

	pattern := "%" + strings.ToLower(queryText) + "%"

	rows, err := db.Query(`
		SELECT b.id, b.title, b.author_id, a.name as author_name,
		       b.isbn, b.price, b.stock, b.published_year, b.description, b.created_at
		FROM books b
		LEFT JOIN authors a ON b.author_id = a.id
		WHERE LOWER(b.title) LIKE ? OR LOWER(a.name) LIKE ?
		ORDER BY b.id ASC
	`, pattern, pattern)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Search failed"})
		return
	}

	books, err := scanBooksWithAuthors(rows)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to read search results"})
		return
	}

	c.JSON(http.StatusOK, gin.H{
		"books": books,
		"count": len(books),
		"query": queryText,
	})
}

func filterBooks(c *gin.Context) {
	minPrice := c.Query("min_price")
	maxPrice := c.Query("max_price")
	author := c.Query("author")
	year := c.Query("year")

	queryBuilder := `
		SELECT b.id, b.title, b.author_id, a.name as author_name,
		       b.isbn, b.price, b.stock, b.published_year, b.description, b.created_at
		FROM books b
		LEFT JOIN authors a ON b.author_id = a.id
		WHERE 1=1
	`
	args := []interface{}{}

	if minPrice != "" {
		queryBuilder += " AND b.price >= ?"
		args = append(args, minPrice)
	}
	if maxPrice != "" {
		queryBuilder += " AND b.price <= ?"
		args = append(args, maxPrice)
	}
	if year != "" {
		queryBuilder += " AND b.published_year = ?"
		args = append(args, year)
	}
	if author != "" {
		queryBuilder += " AND LOWER(a.name) LIKE ?"
		args = append(args, "%"+strings.ToLower(author)+"%")
	}

	queryBuilder += " ORDER BY b.id ASC"

	rows, err := db.Query(queryBuilder, args...)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Filter query failed"})
		return
	}

	books, err := scanBooksWithAuthors(rows)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to read filtered books"})
		return
	}

	c.JSON(http.StatusOK, gin.H{
		"books": books,
		"count": len(books),
		"filters": gin.H{
			"min_price": minPrice,
			"max_price": maxPrice,
			"year":      year,
			"author":    author,
		},
	})
}

func getAuthors(c *gin.Context) {
	rows, err := db.Query(`
		SELECT id, name, bio, birth_year, country, created_at
		FROM authors
		ORDER BY id
	`)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to fetch authors"})
		return
	}
	defer rows.Close()

	authors := []Author{}
	for rows.Next() {
		var author Author
		err := rows.Scan(&author.ID, &author.Name, &author.Bio, &author.BirthYear, &author.Country, &author.CreatedAt)
		if err != nil {
			c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to read authors"})
			return
		}
		authors = append(authors, author)
	}

	c.JSON(http.StatusOK, gin.H{
		"authors": authors,
		"count":   len(authors),
	})
}

func getAuthor(c *gin.Context) {
	id := c.Param("id")

	var author Author
	err := db.QueryRow(`
		SELECT id, name, bio, birth_year, country, created_at
		FROM authors
		WHERE id = ?
	`, id).Scan(&author.ID, &author.Name, &author.Bio, &author.BirthYear, &author.Country, &author.CreatedAt)

	if err == sql.ErrNoRows {
		c.JSON(http.StatusNotFound, gin.H{"error": "Author not found"})
		return
	}
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Database error"})
		return
	}

	c.JSON(http.StatusOK, author)
}

func createAuthor(c *gin.Context) {
	var author Author
	if err := c.ShouldBindJSON(&author); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{
			"error":   "Invalid request data",
			"details": err.Error(),
		})
		return
	}

	result, err := db.Exec(`
		INSERT INTO authors (name, bio, birth_year, country)
		VALUES (?, ?, ?, ?)
	`, author.Name, author.Bio, author.BirthYear, author.Country)
	if err != nil {
		if strings.Contains(strings.ToLower(err.Error()), "unique") {
			c.JSON(http.StatusConflict, gin.H{"error": "Author name already exists"})
			return
		}
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to create author"})
		return
	}

	id, _ := result.LastInsertId()
	_ = db.QueryRow(`
		SELECT id, name, bio, birth_year, country, created_at
		FROM authors
		WHERE id = ?
	`, id).Scan(&author.ID, &author.Name, &author.Bio, &author.BirthYear, &author.Country, &author.CreatedAt)

	c.JSON(http.StatusCreated, author)
}

func updateAuthor(c *gin.Context) {
	id := c.Param("id")

	var author Author
	if err := c.ShouldBindJSON(&author); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{
			"error":   "Invalid request data",
			"details": err.Error(),
		})
		return
	}

	result, err := db.Exec(`
		UPDATE authors
		SET name = ?, bio = ?, birth_year = ?, country = ?
		WHERE id = ?
	`, author.Name, author.Bio, author.BirthYear, author.Country, id)
	if err != nil {
		if strings.Contains(strings.ToLower(err.Error()), "unique") {
			c.JSON(http.StatusConflict, gin.H{"error": "Author name already exists"})
			return
		}
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to update author"})
		return
	}

	rowsAffected, _ := result.RowsAffected()
	if rowsAffected == 0 {
		c.JSON(http.StatusNotFound, gin.H{"error": "Author not found"})
		return
	}

	getAuthor(c)
}

func deleteAuthor(c *gin.Context) {
	id := c.Param("id")

	var bookCount int
	err := db.QueryRow("SELECT COUNT(*) FROM books WHERE author_id = ?", id).Scan(&bookCount)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to check author books"})
		return
	}

	if bookCount > 0 {
		c.JSON(http.StatusBadRequest, gin.H{
			"error":      "Cannot delete author with existing books",
			"book_count": bookCount,
		})
		return
	}

	result, err := db.Exec("DELETE FROM authors WHERE id = ?", id)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to delete author"})
		return
	}

	rowsAffected, _ := result.RowsAffected()
	if rowsAffected == 0 {
		c.JSON(http.StatusNotFound, gin.H{"error": "Author not found"})
		return
	}

	c.JSON(http.StatusOK, gin.H{"message": "Author deleted successfully"})
}

func getAuthorBooks(c *gin.Context) {
	authorID := c.Param("id")

	var author Author
	err := db.QueryRow(`
		SELECT id, name, bio, birth_year, country, created_at
		FROM authors
		WHERE id = ?
	`, authorID).Scan(&author.ID, &author.Name, &author.Bio, &author.BirthYear, &author.Country, &author.CreatedAt)
	if err == sql.ErrNoRows {
		c.JSON(http.StatusNotFound, gin.H{"error": "Author not found"})
		return
	}
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Database error"})
		return
	}

	rows, err := db.Query(`
		SELECT b.id, b.title, b.author_id, a.name as author_name,
		       b.isbn, b.price, b.stock, b.published_year, b.description, b.created_at
		FROM books b
		LEFT JOIN authors a ON b.author_id = a.id
		WHERE b.author_id = ?
		ORDER BY b.id
	`, authorID)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to fetch author books"})
		return
	}

	books, err := scanBooksWithAuthors(rows)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to read author books"})
		return
	}

	c.JSON(http.StatusOK, gin.H{
		"author": author,
		"books":  books,
		"count":  len(books),
	})
}

func main() {
	if err := initDB(); err != nil {
		log.Fatal("Failed to initialize database:", err)
	}
	defer db.Close()

	seedAuthors()
	seedBooks()

	router := gin.Default()

	router.GET("/books/search", searchBooks)
	router.GET("/books/filter", filterBooks)

	router.GET("/books", getBooks)
	router.GET("/books/:id", getBook)
	router.POST("/books", createBook)
	router.PUT("/books/:id", updateBook)
	router.DELETE("/books/:id", deleteBook)

	router.GET("/authors", getAuthors)
	router.GET("/authors/:id", getAuthor)
	router.POST("/authors", createAuthor)
	router.PUT("/authors/:id", updateAuthor)
	router.DELETE("/authors/:id", deleteAuthor)
	router.GET("/authors/:id/books", getAuthorBooks)

	log.Println("Server starting on :8080")
	if err := router.Run(":8080"); err != nil {
		log.Fatal(err)
	}
}