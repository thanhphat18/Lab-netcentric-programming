package main

import (
	"database/sql"
	"fmt"
	"log"
	"net/http"
	"regexp"
	"strconv"
	"strings"
	"time"

	"github.com/gin-gonic/gin"
	_ "github.com/mattn/go-sqlite3"
)

type Author struct {
	ID        int    `json:"id"`
	Name      string `json:"name" binding:"required"`
	Bio       string `json:"bio"`
	BirthYear int    `json:"birth_year"`
	Country   string `json:"country"`
	CreatedAt string `json:"created_at"`
}

type Book struct {
	ID            int     `json:"id"`
	Title         string  `json:"title" binding:"required,min=3"`
	AuthorID      int     `json:"author_id" binding:"required"`
	ISBN          string  `json:"isbn" binding:"required"`
	Price         float64 `json:"price" binding:"required,gte=0.01,lte=1000"`
	Stock         int     `json:"stock" binding:"gte=0"`
	PublishedYear int     `json:"published_year"`
	Description   string  `json:"description"`
	CreatedAt     string  `json:"created_at"`
}

type BookWithAuthor struct {
	ID            int     `json:"id"`
	Title         string  `json:"title"`
	AuthorID      int     `json:"author_id"`
	AuthorName    string  `json:"author_name"`
	ISBN          string  `json:"isbn"`
	Price         float64 `json:"price"`
	Stock         int     `json:"stock"`
	PublishedYear int     `json:"published_year"`
	Description   string  `json:"description"`
	CreatedAt     string  `json:"created_at"`
}

type PaginationMeta struct {
	Page       int  `json:"page"`
	Limit      int  `json:"limit"`
	Total      int  `json:"total"`
	TotalPages int  `json:"total_pages"`
	HasNext    bool `json:"has_next"`
	HasPrev    bool `json:"has_prev"`
}

type PaginatedBooksResponse struct {
	Books      []BookWithAuthor `json:"books"`
	Pagination PaginationMeta   `json:"pagination"`
}

type Statistics struct {
	TotalBooks    int             `json:"total_books"`
	TotalAuthors  int             `json:"total_authors"`
	TotalValue    float64         `json:"total_value"`
	LowStock      int             `json:"low_stock"`
	OutOfStock    int             `json:"out_of_stock"`
	MostExpensive *BookWithAuthor `json:"most_expensive"`
	Cheapest      *BookWithAuthor `json:"cheapest"`
	MostStocked   *BookWithAuthor `json:"most_stocked"`
	BooksByYear   map[int]int     `json:"books_by_year"`
	AveragePrice  float64         `json:"average_price"`
}

type RestockRequest struct {
	Quantity int `json:"quantity" binding:"required,gt=0"`
}

type SellRequest struct {
	Quantity int `json:"quantity" binding:"required,gt=0"`
}

type BulkCreateRequest struct {
	Books []Book `json:"books" binding:"required,min=1,dive"`
}

type BulkCreateResponse struct {
	Success      int      `json:"success"`
	Failed       int      `json:"failed"`
	CreatedBooks []Book   `json:"created_books"`
	Errors       []string `json:"errors,omitempty"`
}

var db *sql.DB

func initDB() error {
	var err error
	db, err = sql.Open("sqlite3", "./bookstore.db")
	if err != nil {
		return err
	}

	createAuthorsSQL := `
	CREATE TABLE IF NOT EXISTS authors (
		id INTEGER PRIMARY KEY AUTOINCREMENT,
		name TEXT NOT NULL UNIQUE,
		bio TEXT,
		birth_year INTEGER,
		country TEXT,
		created_at DATETIME DEFAULT CURRENT_TIMESTAMP
	);`
	if _, err = db.Exec(createAuthorsSQL); err != nil {
		return err
	}

	createBooksSQL := `
	CREATE TABLE IF NOT EXISTS books (
		id INTEGER PRIMARY KEY AUTOINCREMENT,
		title TEXT NOT NULL,
		author_id INTEGER NOT NULL,
		isbn TEXT NOT NULL UNIQUE,
		price REAL NOT NULL CHECK(price > 0),
		stock INTEGER DEFAULT 0,
		published_year INTEGER,
		description TEXT,
		created_at DATETIME DEFAULT CURRENT_TIMESTAMP
	);`
	_, err = db.Exec(createBooksSQL)
	return err
}

func seedAuthors() {
	var count int
	err := db.QueryRow("SELECT COUNT(*) FROM authors").Scan(&count)
	if err != nil || count > 0 {
		return
	}

	authors := []Author{
		{Name: "Robert C. Martin", Bio: "Software engineer and author", BirthYear: 1952, Country: "USA"},
		{Name: "Gang of Four", Bio: "Design patterns pioneers", BirthYear: 0, Country: "Various"},
		{Name: "Alan Donovan", Bio: "Go team member and author", BirthYear: 0, Country: "USA"},
		{Name: "Andrew Hunt", Bio: "Author of The Pragmatic Programmer", BirthYear: 1964, Country: "USA"},
		{Name: "Steve McConnell", Bio: "Software engineering author", BirthYear: 1962, Country: "USA"},
		{Name: "Jon Bodner", Bio: "Go programming author", BirthYear: 0, Country: "USA"},
	}

	for _, author := range authors {
		_, err := db.Exec(
			"INSERT INTO authors (name, bio, birth_year, country) VALUES (?, ?, ?, ?)",
			author.Name, author.Bio, author.BirthYear, author.Country,
		)
		if err != nil {
			log.Printf("warning: failed to seed author %q: %v", author.Name, err)
		}
	}
}

func getAuthorIDByName(name string) int {
	var id int
	err := db.QueryRow("SELECT id FROM authors WHERE name = ?", name).Scan(&id)
	if err != nil {
		return 0
	}
	return id
}

func seedBooks() {
	var count int
	err := db.QueryRow("SELECT COUNT(*) FROM books").Scan(&count)
	if err != nil || count > 0 {
		return
	}

	books := []Book{
		{Title: "The Go Programming Language", AuthorID: getAuthorIDByName("Alan Donovan"), ISBN: "9780134190440", Price: 39.99, Stock: 15, PublishedYear: 2015, Description: "Complete guide to Go"},
		{Title: "Clean Code", AuthorID: getAuthorIDByName("Robert C. Martin"), ISBN: "9780132350884", Price: 42.50, Stock: 20, PublishedYear: 2008, Description: "Handbook of Agile Software Craftsmanship"},
		{Title: "Design Patterns", AuthorID: getAuthorIDByName("Gang of Four"), ISBN: "9780201633610", Price: 54.99, Stock: 8, PublishedYear: 1994, Description: "Elements of Reusable Object-Oriented Software"},
		{Title: "The Pragmatic Programmer", AuthorID: getAuthorIDByName("Andrew Hunt"), ISBN: "9780135957059", Price: 47.99, Stock: 12, PublishedYear: 2019, Description: "Journey to mastery"},
		{Title: "Code Complete", AuthorID: getAuthorIDByName("Steve McConnell"), ISBN: "9780735619678", Price: 49.99, Stock: 10, PublishedYear: 2004, Description: "Practical handbook of software construction"},
		{Title: "Learning Go", AuthorID: getAuthorIDByName("Jon Bodner"), ISBN: "9781492077213", Price: 44.99, Stock: 14, PublishedYear: 2021, Description: "Idiomatic Go for real-world programming"},
	}

	for _, book := range books {
		_, err := db.Exec(
			`INSERT INTO books (title, author_id, isbn, price, stock, published_year, description)
			 VALUES (?, ?, ?, ?, ?, ?, ?)`,
			book.Title, book.AuthorID, book.ISBN, book.Price, book.Stock, book.PublishedYear, book.Description,
		)
		if err != nil {
			log.Printf("warning: failed to seed book %q: %v", book.Title, err)
		}
	}
}

func parseIntQuery(c *gin.Context, key string, defaultValue int) int {
	valueStr := c.Query(key)
	if valueStr == "" {
		return defaultValue
	}
	value, err := strconv.Atoi(valueStr)
	if err != nil {
		return defaultValue
	}
	return value
}

func validateISBN(isbn string) error {
	isbn = regexp.MustCompile(`-`).ReplaceAllString(isbn, "")
	if len(isbn) != 10 && len(isbn) != 13 {
		return fmt.Errorf("ISBN must be 10 or 13 digits")
	}
	if !regexp.MustCompile(`^\d+$`).MatchString(isbn) {
		return fmt.Errorf("ISBN must contain only digits")
	}
	return nil
}

func validatePublishedYear(year int) error {
	currentYear := time.Now().Year()
	if year < 1800 || year > currentYear {
		return fmt.Errorf("published year must be between 1800 and %d", currentYear)
	}
	return nil
}

func authorExists(authorID int) bool {
	var exists bool
	err := db.QueryRow("SELECT EXISTS(SELECT 1 FROM authors WHERE id = ?)", authorID).Scan(&exists)
	return err == nil && exists
}

func validateBookInput(book Book) error {
	if err := validateISBN(book.ISBN); err != nil {
		return err
	}
	if err := validatePublishedYear(book.PublishedYear); err != nil {
		return err
	}
	if !authorExists(book.AuthorID) {
		return fmt.Errorf("author with ID %d does not exist", book.AuthorID)
	}
	return nil
}

func scanBooksWithAuthors(rows *sql.Rows) ([]BookWithAuthor, error) {
	defer rows.Close()

	books := []BookWithAuthor{}
	for rows.Next() {
		var book BookWithAuthor
		err := rows.Scan(
			&book.ID,
			&book.Title,
			&book.AuthorID,
			&book.AuthorName,
			&book.ISBN,
			&book.Price,
			&book.Stock,
			&book.PublishedYear,
			&book.Description,
			&book.CreatedAt,
		)
		if err != nil {
			return nil, err
		}
		books = append(books, book)
	}
	return books, nil
}

func getBookWithAuthorByID(id string) (*BookWithAuthor, error) {
	var book BookWithAuthor
	err := db.QueryRow(`
		SELECT b.id, b.title, b.author_id, a.name as author_name,
		       b.isbn, b.price, b.stock, b.published_year, b.description, b.created_at
		FROM books b
		LEFT JOIN authors a ON b.author_id = a.id
		WHERE b.id = ?
	`, id).Scan(
		&book.ID,
		&book.Title,
		&book.AuthorID,
		&book.AuthorName,
		&book.ISBN,
		&book.Price,
		&book.Stock,
		&book.PublishedYear,
		&book.Description,
		&book.CreatedAt,
	)
	if err != nil {
		return nil, err
	}
	return &book, nil
}

func getBooks(c *gin.Context) {
	page := parseIntQuery(c, "page", 1)
	limit := parseIntQuery(c, "limit", 20)
	sortBy := c.DefaultQuery("sort", "id")
	minPrice := c.Query("min_price")
	maxPrice := c.Query("max_price")
	year := c.Query("year")
	author := c.Query("author")

	if page < 1 {
		page = 1
	}
	if limit < 1 || limit > 100 {
		limit = 20
	}
	offset := (page - 1) * limit

	validSorts := map[string]string{
		"price_asc":  "b.price ASC",
		"price_desc": "b.price DESC",
		"title":      "b.title ASC",
		"year_desc":  "b.published_year DESC",
		"id":         "b.id ASC",
	}
	orderBy, ok := validSorts[sortBy]
	if !ok {
		orderBy = "b.id ASC"
	}

	whereClause := " WHERE 1=1"
	args := []interface{}{}
	if minPrice != "" {
		whereClause += " AND b.price >= ?"
		args = append(args, minPrice)
	}
	if maxPrice != "" {
		whereClause += " AND b.price <= ?"
		args = append(args, maxPrice)
	}
	if year != "" {
		whereClause += " AND b.published_year = ?"
		args = append(args, year)
	}
	if author != "" {
		whereClause += " AND LOWER(a.name) LIKE ?"
		args = append(args, "%"+strings.ToLower(author)+"%")
	}

	countQuery := `
		SELECT COUNT(*)
		FROM books b
		LEFT JOIN authors a ON b.author_id = a.id` + whereClause

	var total int
	err := db.QueryRow(countQuery, args...).Scan(&total)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to count books"})
		return
	}

	dataQuery := `
		SELECT b.id, b.title, b.author_id, a.name as author_name,
		       b.isbn, b.price, b.stock, b.published_year, b.description, b.created_at
		FROM books b
		LEFT JOIN authors a ON b.author_id = a.id` + whereClause + `
		ORDER BY ` + orderBy + `
		LIMIT ? OFFSET ?`

	dataArgs := append(args, limit, offset)
	rows, err := db.Query(dataQuery, dataArgs...)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to fetch books"})
		return
	}

	books, err := scanBooksWithAuthors(rows)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to read books"})
		return
	}

	totalPages := 0
	if total > 0 {
		totalPages = (total + limit - 1) / limit
	}

	c.JSON(http.StatusOK, PaginatedBooksResponse{
		Books: books,
		Pagination: PaginationMeta{
			Page:       page,
			Limit:      limit,
			Total:      total,
			TotalPages: totalPages,
			HasNext:    page < totalPages,
			HasPrev:    page > 1,
		},
	})
}

func getBook(c *gin.Context) {
	book, err := getBookWithAuthorByID(c.Param("id"))
	if err == sql.ErrNoRows {
		c.JSON(http.StatusNotFound, gin.H{"error": "Book not found"})
		return
	}
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Database error"})
		return
	}
	c.JSON(http.StatusOK, book)
}

func createBook(c *gin.Context) {
	var book Book
	if err := c.ShouldBindJSON(&book); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Validation failed", "details": err.Error()})
		return
	}
	if err := validateBookInput(book); err != nil {
		msg := err.Error()
		if strings.Contains(msg, "ISBN") {
			c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid ISBN", "details": msg})
			return
		}
		if strings.Contains(msg, "published year") {
			c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid published year", "details": msg})
			return
		}
		if strings.Contains(msg, "author with ID") {
			c.JSON(http.StatusBadRequest, gin.H{"error": "Author not found", "details": msg})
			return
		}
		c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid book data", "details": msg})
		return
	}

	result, err := db.Exec(`
		INSERT INTO books (title, author_id, isbn, price, stock, published_year, description)
		VALUES (?, ?, ?, ?, ?, ?, ?)
	`, book.Title, book.AuthorID, book.ISBN, book.Price, book.Stock, book.PublishedYear, book.Description)
	if err != nil {
		if strings.Contains(strings.ToLower(err.Error()), "unique") {
			c.JSON(http.StatusConflict, gin.H{"error": "ISBN already exists"})
			return
		}
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to create book"})
		return
	}

	id, _ := result.LastInsertId()
	created, err := getBookWithAuthorByID(strconv.FormatInt(id, 10))
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to fetch created book"})
		return
	}
	c.JSON(http.StatusCreated, created)
}

func updateBook(c *gin.Context) {
	id := c.Param("id")
	var book Book
	if err := c.ShouldBindJSON(&book); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Validation failed", "details": err.Error()})
		return
	}
	if err := validateBookInput(book); err != nil {
		msg := err.Error()
		if strings.Contains(msg, "ISBN") {
			c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid ISBN", "details": msg})
			return
		}
		if strings.Contains(msg, "published year") {
			c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid published year", "details": msg})
			return
		}
		if strings.Contains(msg, "author with ID") {
			c.JSON(http.StatusBadRequest, gin.H{"error": "Author not found", "details": msg})
			return
		}
		c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid book data", "details": msg})
		return
	}

	result, err := db.Exec(`
		UPDATE books
		SET title = ?, author_id = ?, isbn = ?, price = ?, stock = ?, published_year = ?, description = ?
		WHERE id = ?
	`, book.Title, book.AuthorID, book.ISBN, book.Price, book.Stock, book.PublishedYear, book.Description, id)
	if err != nil {
		if strings.Contains(strings.ToLower(err.Error()), "unique") {
			c.JSON(http.StatusConflict, gin.H{"error": "ISBN already exists"})
			return
		}
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to update book"})
		return
	}

	rowsAffected, _ := result.RowsAffected()
	if rowsAffected == 0 {
		c.JSON(http.StatusNotFound, gin.H{"error": "Book not found"})
		return
	}

	updated, err := getBookWithAuthorByID(id)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to fetch updated book"})
		return
	}
	c.JSON(http.StatusOK, updated)
}

func deleteBook(c *gin.Context) {
	result, err := db.Exec("DELETE FROM books WHERE id = ?", c.Param("id"))
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to delete book"})
		return
	}
	rowsAffected, _ := result.RowsAffected()
	if rowsAffected == 0 {
		c.JSON(http.StatusNotFound, gin.H{"error": "Book not found"})
		return
	}
	c.JSON(http.StatusOK, gin.H{"message": "Book deleted successfully"})
}

func searchBooks(c *gin.Context) {
	queryText := strings.TrimSpace(c.Query("q"))
	if queryText == "" {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Search query required"})
		return
	}
	pattern := "%" + strings.ToLower(queryText) + "%"
	rows, err := db.Query(`
		SELECT b.id, b.title, b.author_id, a.name as author_name,
		       b.isbn, b.price, b.stock, b.published_year, b.description, b.created_at
		FROM books b
		LEFT JOIN authors a ON b.author_id = a.id
		WHERE LOWER(b.title) LIKE ? OR LOWER(a.name) LIKE ?
		ORDER BY b.id ASC
	`, pattern, pattern)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Search failed"})
		return
	}
	books, err := scanBooksWithAuthors(rows)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to read search results"})
		return
	}
	c.JSON(http.StatusOK, gin.H{"books": books, "count": len(books), "query": queryText})
}

func filterBooks(c *gin.Context) {
	minPrice := c.Query("min_price")
	maxPrice := c.Query("max_price")
	author := c.Query("author")
	year := c.Query("year")

	queryBuilder := `
		SELECT b.id, b.title, b.author_id, a.name as author_name,
		       b.isbn, b.price, b.stock, b.published_year, b.description, b.created_at
		FROM books b
		LEFT JOIN authors a ON b.author_id = a.id
		WHERE 1=1`
	args := []interface{}{}

	if minPrice != "" {
		queryBuilder += " AND b.price >= ?"
		args = append(args, minPrice)
	}
	if maxPrice != "" {
		queryBuilder += " AND b.price <= ?"
		args = append(args, maxPrice)
	}
	if year != "" {
		queryBuilder += " AND b.published_year = ?"
		args = append(args, year)
	}
	if author != "" {
		queryBuilder += " AND LOWER(a.name) LIKE ?"
		args = append(args, "%"+strings.ToLower(author)+"%")
	}
	queryBuilder += " ORDER BY b.id ASC"

	rows, err := db.Query(queryBuilder, args...)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Filter query failed"})
		return
	}
	books, err := scanBooksWithAuthors(rows)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to read filtered books"})
		return
	}
	c.JSON(http.StatusOK, gin.H{
		"books": books,
		"count": len(books),
		"filters": gin.H{
			"min_price": minPrice,
			"max_price": maxPrice,
			"year":      year,
			"author":    author,
		},
	})
}

func getAuthors(c *gin.Context) {
	rows, err := db.Query(`SELECT id, name, bio, birth_year, country, created_at FROM authors ORDER BY id`)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to fetch authors"})
		return
	}
	defer rows.Close()

	authors := []Author{}
	for rows.Next() {
		var author Author
		if err := rows.Scan(&author.ID, &author.Name, &author.Bio, &author.BirthYear, &author.Country, &author.CreatedAt); err != nil {
			c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to read authors"})
			return
		}
		authors = append(authors, author)
	}
	c.JSON(http.StatusOK, gin.H{"authors": authors, "count": len(authors)})
}

func getAuthor(c *gin.Context) {
	var author Author
	err := db.QueryRow(`SELECT id, name, bio, birth_year, country, created_at FROM authors WHERE id = ?`, c.Param("id")).Scan(
		&author.ID, &author.Name, &author.Bio, &author.BirthYear, &author.Country, &author.CreatedAt,
	)
	if err == sql.ErrNoRows {
		c.JSON(http.StatusNotFound, gin.H{"error": "Author not found"})
		return
	}
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Database error"})
		return
	}
	c.JSON(http.StatusOK, author)
}

func createAuthor(c *gin.Context) {
	var author Author
	if err := c.ShouldBindJSON(&author); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid request data", "details": err.Error()})
		return
	}
	result, err := db.Exec(`INSERT INTO authors (name, bio, birth_year, country) VALUES (?, ?, ?, ?)`, author.Name, author.Bio, author.BirthYear, author.Country)
	if err != nil {
		if strings.Contains(strings.ToLower(err.Error()), "unique") {
			c.JSON(http.StatusConflict, gin.H{"error": "Author name already exists"})
			return
		}
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to create author"})
		return
	}
	id, _ := result.LastInsertId()
	_ = db.QueryRow(`SELECT id, name, bio, birth_year, country, created_at FROM authors WHERE id = ?`, id).Scan(
		&author.ID, &author.Name, &author.Bio, &author.BirthYear, &author.Country, &author.CreatedAt,
	)
	c.JSON(http.StatusCreated, author)
}

func updateAuthor(c *gin.Context) {
	id := c.Param("id")
	var author Author
	if err := c.ShouldBindJSON(&author); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid request data", "details": err.Error()})
		return
	}
	result, err := db.Exec(`UPDATE authors SET name = ?, bio = ?, birth_year = ?, country = ? WHERE id = ?`, author.Name, author.Bio, author.BirthYear, author.Country, id)
	if err != nil {
		if strings.Contains(strings.ToLower(err.Error()), "unique") {
			c.JSON(http.StatusConflict, gin.H{"error": "Author name already exists"})
			return
		}
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to update author"})
		return
	}
	rowsAffected, _ := result.RowsAffected()
	if rowsAffected == 0 {
		c.JSON(http.StatusNotFound, gin.H{"error": "Author not found"})
		return
	}
	getAuthor(c)
}

func deleteAuthor(c *gin.Context) {
	id := c.Param("id")
	var bookCount int
	if err := db.QueryRow("SELECT COUNT(*) FROM books WHERE author_id = ?", id).Scan(&bookCount); err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to check author books"})
		return
	}
	if bookCount > 0 {
		c.JSON(http.StatusBadRequest, gin.H{
			"error":      "Cannot delete author with existing books",
			"book_count": bookCount,
		})
		return
	}
	result, err := db.Exec("DELETE FROM authors WHERE id = ?", id)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to delete author"})
		return
	}
	rowsAffected, _ := result.RowsAffected()
	if rowsAffected == 0 {
		c.JSON(http.StatusNotFound, gin.H{"error": "Author not found"})
		return
	}
	c.JSON(http.StatusOK, gin.H{"message": "Author deleted successfully"})
}

func getAuthorBooks(c *gin.Context) {
	authorID := c.Param("id")

	var author Author
	err := db.QueryRow(`SELECT id, name, bio, birth_year, country, created_at FROM authors WHERE id = ?`, authorID).Scan(
		&author.ID, &author.Name, &author.Bio, &author.BirthYear, &author.Country, &author.CreatedAt,
	)
	if err == sql.ErrNoRows {
		c.JSON(http.StatusNotFound, gin.H{"error": "Author not found"})
		return
	}
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Database error"})
		return
	}

	rows, err := db.Query(`
		SELECT b.id, b.title, b.author_id, a.name as author_name,
		       b.isbn, b.price, b.stock, b.published_year, b.description, b.created_at
		FROM books b
		LEFT JOIN authors a ON b.author_id = a.id
		WHERE b.author_id = ?
		ORDER BY b.id
	`, authorID)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to fetch author books"})
		return
	}
	books, err := scanBooksWithAuthors(rows)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to read author books"})
		return
	}
	c.JSON(http.StatusOK, gin.H{"author": author, "books": books, "count": len(books)})
}

func getStatistics(c *gin.Context) {
	var stats Statistics
	stats.BooksByYear = map[int]int{}

	_ = db.QueryRow("SELECT COUNT(*) FROM books").Scan(&stats.TotalBooks)
	_ = db.QueryRow("SELECT COUNT(*) FROM authors").Scan(&stats.TotalAuthors)
	_ = db.QueryRow("SELECT COALESCE(SUM(price * stock), 0) FROM books").Scan(&stats.TotalValue)
	_ = db.QueryRow("SELECT COUNT(*) FROM books WHERE stock < 10 AND stock > 0").Scan(&stats.LowStock)
	_ = db.QueryRow("SELECT COUNT(*) FROM books WHERE stock = 0").Scan(&stats.OutOfStock)
	_ = db.QueryRow("SELECT COALESCE(AVG(price), 0) FROM books").Scan(&stats.AveragePrice)

	getExtreme := func(orderBy string) *BookWithAuthor {
		row := db.QueryRow(`
			SELECT b.id, b.title, b.author_id, a.name as author_name,
			       b.isbn, b.price, b.stock, b.published_year, b.description, b.created_at
			FROM books b
			LEFT JOIN authors a ON b.author_id = a.id
			ORDER BY ` + orderBy + ` LIMIT 1`)
		var book BookWithAuthor
		err := row.Scan(&book.ID, &book.Title, &book.AuthorID, &book.AuthorName, &book.ISBN, &book.Price, &book.Stock, &book.PublishedYear, &book.Description, &book.CreatedAt)
		if err != nil {
			return nil
		}
		return &book
	}

	stats.MostExpensive = getExtreme("b.price DESC")
	stats.Cheapest = getExtreme("b.price ASC")
	stats.MostStocked = getExtreme("b.stock DESC")

	rows, err := db.Query("SELECT published_year, COUNT(*) FROM books GROUP BY published_year ORDER BY published_year")
	if err == nil {
		defer rows.Close()
		for rows.Next() {
			var year, count int
			if err := rows.Scan(&year, &count); err == nil {
				stats.BooksByYear[year] = count
			}
		}
	}

	c.JSON(http.StatusOK, stats)
}

func getTopExpensive(c *gin.Context) {
	limit := parseIntQuery(c, "limit", 5)
	if limit < 1 {
		limit = 5
	}
	rows, err := db.Query(`
		SELECT b.id, b.title, b.author_id, a.name as author_name,
		       b.isbn, b.price, b.stock, b.published_year, b.description, b.created_at
		FROM books b
		LEFT JOIN authors a ON b.author_id = a.id
		ORDER BY b.price DESC
		LIMIT ?`, limit)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to fetch top expensive books"})
		return
	}
	books, err := scanBooksWithAuthors(rows)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to read books"})
		return
	}
	c.JSON(http.StatusOK, gin.H{"books": books, "count": len(books)})
}

func getTopStocked(c *gin.Context) {
	limit := parseIntQuery(c, "limit", 5)
	if limit < 1 {
		limit = 5
	}
	rows, err := db.Query(`
		SELECT b.id, b.title, b.author_id, a.name as author_name,
		       b.isbn, b.price, b.stock, b.published_year, b.description, b.created_at
		FROM books b
		LEFT JOIN authors a ON b.author_id = a.id
		ORDER BY b.stock DESC
		LIMIT ?`, limit)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to fetch top stocked books"})
		return
	}
	books, err := scanBooksWithAuthors(rows)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to read books"})
		return
	}
	c.JSON(http.StatusOK, gin.H{"books": books, "count": len(books)})
}

func getRecentBooks(c *gin.Context) {
	limit := parseIntQuery(c, "limit", 10)
	if limit < 1 {
		limit = 10
	}
	rows, err := db.Query(`
		SELECT b.id, b.title, b.author_id, a.name as author_name,
		       b.isbn, b.price, b.stock, b.published_year, b.description, b.created_at
		FROM books b
		LEFT JOIN authors a ON b.author_id = a.id
		ORDER BY b.created_at DESC
		LIMIT ?`, limit)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to fetch recent books"})
		return
	}
	books, err := scanBooksWithAuthors(rows)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to read books"})
		return
	}
	c.JSON(http.StatusOK, gin.H{"books": books, "count": len(books)})
}

func restockBook(c *gin.Context) {
	id := c.Param("id")
	var req RestockRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid request", "details": err.Error()})
		return
	}
	result, err := db.Exec("UPDATE books SET stock = stock + ? WHERE id = ?", req.Quantity, id)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to restock"})
		return
	}
	rowsAffected, _ := result.RowsAffected()
	if rowsAffected == 0 {
		c.JSON(http.StatusNotFound, gin.H{"error": "Book not found"})
		return
	}
	book, err := getBookWithAuthorByID(id)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to fetch updated book"})
		return
	}
	c.JSON(http.StatusOK, gin.H{"message": "Book restocked successfully", "book": book})
}

func sellBook(c *gin.Context) {
	id := c.Param("id")
	var req SellRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid request", "details": err.Error()})
		return
	}
	var currentStock int
	err := db.QueryRow("SELECT stock FROM books WHERE id = ?", id).Scan(&currentStock)
	if err == sql.ErrNoRows {
		c.JSON(http.StatusNotFound, gin.H{"error": "Book not found"})
		return
	}
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to check stock"})
		return
	}
	if currentStock < req.Quantity {
		c.JSON(http.StatusBadRequest, gin.H{
			"error":     "Insufficient stock",
			"available": currentStock,
			"requested": req.Quantity,
		})
		return
	}
	if _, err := db.Exec("UPDATE books SET stock = stock - ? WHERE id = ?", req.Quantity, id); err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to sell book"})
		return
	}
	book, err := getBookWithAuthorByID(id)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to fetch updated book"})
		return
	}
	c.JSON(http.StatusOK, gin.H{"message": "Book sold successfully", "book": book})
}

func createBulkBooks(c *gin.Context) {
	var req BulkCreateRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid request", "details": err.Error()})
		return
	}
	response := BulkCreateResponse{}
	for _, book := range req.Books {
		if err := validateBookInput(book); err != nil {
			response.Failed++
			response.Errors = append(response.Errors, fmt.Sprintf("Book '%s': %v", book.Title, err))
			continue
		}
		result, err := db.Exec(
			`INSERT INTO books (title, author_id, isbn, price, stock, published_year, description) VALUES (?, ?, ?, ?, ?, ?, ?)`,
			book.Title, book.AuthorID, book.ISBN, book.Price, book.Stock, book.PublishedYear, book.Description,
		)
		if err != nil {
			response.Failed++
			response.Errors = append(response.Errors, fmt.Sprintf("Book '%s': %v", book.Title, err))
			continue
		}
		id, _ := result.LastInsertId()
		book.ID = int(id)
		response.CreatedBooks = append(response.CreatedBooks, book)
		response.Success++
	}
	c.JSON(http.StatusCreated, response)
}

func getAPIDocumentation(c *gin.Context) {
	docs := gin.H{
		"name":    "Bookstore API",
		"version": "1.0.0",
		"endpoints": gin.H{
			"books": []string{
				"GET /books - List books with pagination",
				"GET /books/:id - Get book by ID",
				"POST /books - Create new book",
				"PUT /books/:id - Update book",
				"DELETE /books/:id - Delete book",
				"GET /books/search?q=query - Search books",
				"GET /books/filter - Filter books",
				"GET /books/top/expensive - Most expensive books",
				"GET /books/top/stocked - Most stocked books",
				"GET /books/top/recent - Recently added books",
				"POST /books/:id/restock - Restock book",
				"POST /books/:id/sell - Sell book",
				"POST /books/bulk - Create multiple books",
			},
			"authors": []string{
				"GET /authors - List all authors",
				"GET /authors/:id - Get author by ID",
				"POST /authors - Create new author",
				"PUT /authors/:id - Update author",
				"DELETE /authors/:id - Delete author",
				"GET /authors/:id/books - Get author's books",
			},
			"statistics": []string{
				"GET /stats - Get bookstore statistics",
			},
		},
		"query_parameters": gin.H{
			"pagination": "?page=1&limit=20",
			"search":     "?q=golang",
			"filter":     "?min_price=20&max_price=50&year=2023",
			"sort":       "?sort=price_asc|price_desc|title|year_desc",
		},
	}
	c.JSON(http.StatusOK, docs)
}

func main() {
	if err := initDB(); err != nil {
		log.Fatal("Failed to initialize database:", err)
	}
	defer db.Close()

	seedAuthors()
	seedBooks()

	router := gin.Default()

	router.GET("/", getAPIDocumentation)

	router.GET("/books/search", searchBooks)
	router.GET("/books/filter", filterBooks)
	router.GET("/books/top/expensive", getTopExpensive)
	router.GET("/books/top/stocked", getTopStocked)
	router.GET("/books/top/recent", getRecentBooks)

	router.GET("/books", getBooks)
	router.GET("/books/:id", getBook)
	router.POST("/books", createBook)
	router.PUT("/books/:id", updateBook)
	router.DELETE("/books/:id", deleteBook)
	router.POST("/books/:id/restock", restockBook)
	router.POST("/books/:id/sell", sellBook)
	router.POST("/books/bulk", createBulkBooks)

	router.GET("/authors", getAuthors)
	router.GET("/authors/:id", getAuthor)
	router.POST("/authors", createAuthor)
	router.PUT("/authors/:id", updateAuthor)
	router.DELETE("/authors/:id", deleteAuthor)
	router.GET("/authors/:id/books", getAuthorBooks)

	router.GET("/stats", getStatistics)

	log.Println("Complete Bookstore API started on :8080")
	if err := router.Run(":8080"); err != nil {
		log.Fatal(err)
	}
}