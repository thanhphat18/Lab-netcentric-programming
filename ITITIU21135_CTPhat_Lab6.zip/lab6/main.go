package main

import (
	"database/sql"
	"log"
	"net/http"

	"github.com/gin-gonic/gin"
	_ "github.com/mattn/go-sqlite3"
)

type Book struct {
	ID            int     `json:"id"`
	Title         string  `json:"title" binding:"required"`
	Author        string  `json:"author" binding:"required"`
	ISBN          string  `json:"isbn"`
	Price         float64 `json:"price" binding:"required,gt=0"`
	Stock         int     `json:"stock" binding:"gte=0"`
	PublishedYear int     `json:"published_year"`
	Description   string  `json:"description"`
	CreatedAt     string  `json:"created_at"`
}

var db *sql.DB

// this function:
// 1. opens SQLite db file bookstore.db
// 2. creates the books table if it does not exits
func initDB() error {
	var err error
	db, err = sql.Open("sqlite3", "./bookstore.db")
	if err != nil {
		return err
	}

	createTableSQL := `
	CREATE TABLE IF NOT EXISTS books (
		id INTEGER PRIMARY KEY AUTOINCREMENT,
		title TEXT NOT NULL,
		author TEXT NOT NULL,
		isbn TEXT UNIQUE,
		price REAL NOT NULL CHECK(price > 0),
		stock INTEGER DEFAULT 0,
		published_year INTEGER,
		description TEXT,
		created_at DATETIME DEFAULT CURRENT_TIMESTAMP
	);`

	_, err = db.Exec(createTableSQL)
	return err
}

//add sample date
func seedData() {
	var count int
	//check how many rows already exits
	err := db.QueryRow("SELECT COUNT(*) FROM books").Scan(&count)
	// if count > 0 -> stop to prevent duplicating 
	if err != nil || count > 0 {
		return
	}

	books := []Book{
		{
			Title:         "The Go Programming Language",
			Author:        "Alan Donovan",
			ISBN:          "978-0134190440",
			Price:         39.99,
			Stock:         15,
			PublishedYear: 2015,
			Description:   "Complete guide to Go",
		},
		{
			Title:         "Clean Code",
			Author:        "Robert Martin",
			ISBN:          "978-0132350884",
			Price:         42.50,
			Stock:         20,
			PublishedYear: 2008,
			Description:   "Handbook of Agile Software Craftsmanship",
		},
		{
			Title:         "Design Patterns",
			Author:        "Gang of Four",
			ISBN:          "978-0201633610",
			Price:         54.99,
			Stock:         8,
			PublishedYear: 1994,
			Description:   "Elements of Reusable Object-Oriented Software",
		},
		{
			Title:         "The Pragmatic Programmer",
			Author:        "Andrew Hunt",
			ISBN:          "978-0135957059",
			Price:         47.99,
			Stock:         12,
			PublishedYear: 2019,
			Description:   "Journey to mastery",
		},
		{
			Title:         "Code Complete",
			Author:        "Steve McConnell",
			ISBN:          "978-0735619678",
			Price:         49.99,
			Stock:         10,
			PublishedYear: 2004,
			Description:   "Practical handbook of software construction",
		},
	}

	for _, book := range books {
		_, err := db.Exec(
			`INSERT INTO books (title, author, isbn, price, stock, published_year, description)
			 VALUES (?, ?, ?, ?, ?, ?, ?)`,
			book.Title,
			book.Author,
			book.ISBN,
			book.Price,
			book.Stock,
			book.PublishedYear,
			book.Description,
		)
		if err != nil {
			log.Printf("warning: failed to seed %q: %v", book.Title, err)
		}
	}
}

func getBooks(c *gin.Context) {
	rows, err := db.Query(`
		SELECT id, title, author, isbn, price, stock, published_year, description, created_at
		FROM books
		ORDER BY id
	`)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{
			"error": "Failed to fetch books",
		})
		return
	}
	defer rows.Close()

	books := []Book{}

	for rows.Next() {
		var book Book
		err := rows.Scan(
			&book.ID,
			&book.Title,
			&book.Author,
			&book.ISBN,
			&book.Price,
			&book.Stock,
			&book.PublishedYear,
			&book.Description,
			&book.CreatedAt,
		)
		if err != nil {
			c.JSON(http.StatusInternalServerError, gin.H{
				"error": "Failed to read book data",
			})
			return
		}
		books = append(books, book)
	}

	c.JSON(http.StatusOK, gin.H{
		"books": books,
		"count": len(books),
	})
}

func getBook(c *gin.Context) {
	//handle GET/books/:id
	id := c.Param("id")

	var book Book
	err := db.QueryRow(`
		SELECT id, title, author, isbn, price, stock, published_year, description, created_at
		FROM books
		WHERE id = ?
	`, id).Scan(
		&book.ID,
		&book.Title,
		&book.Author,
		&book.ISBN,
		&book.Price,
		&book.Stock,
		&book.PublishedYear,
		&book.Description,
		&book.CreatedAt,
	)

	if err == sql.ErrNoRows {
		c.JSON(http.StatusNotFound, gin.H{
			"error": "Book not found",
		})
		return
	}
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{
			"error": "Database error",
		})
		return
	}

	c.JSON(http.StatusOK, book)
}

func createBook(c *gin.Context) {
	var book Book
	//request body and fills the book struct
	if err := c.ShouldBindJSON(&book); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{
			"error":   "Invalid request data",
			"details": err.Error(),
		})
		return
	}

	result, err := db.Exec(`
		INSERT INTO books (title, author, isbn, price, stock, published_year, description)
		VALUES (?, ?, ?, ?, ?, ?, ?)
	`,
		book.Title,
		book.Author,
		book.ISBN,
		book.Price,
		book.Stock,
		book.PublishedYear,
		book.Description,
	)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{
			"error": "Failed to create book",
		})
		return
	}

	id, _ := result.LastInsertId()
	book.ID = int(id)

	_ = db.QueryRow("SELECT created_at FROM books WHERE id = ?", id).Scan(&book.CreatedAt)

	c.JSON(http.StatusCreated, book)
}

//handle PUT/books/:id
//1. gets ID from URL
//2. binds JSON body
//3. runs UPDATE...WHERE id=?
func updateBook(c *gin.Context) {
	id := c.Param("id")

	var book Book
	if err := c.ShouldBindJSON(&book); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{
			"error":   "Invalid request data",
			"details": err.Error(),
		})
		return
	}

	result, err := db.Exec(`
		UPDATE books
		SET title = ?, author = ?, isbn = ?, price = ?, stock = ?, published_year = ?, description = ?
		WHERE id = ?
	`,
		book.Title,
		book.Author,
		book.ISBN,
		book.Price,
		book.Stock,
		book.PublishedYear,
		book.Description,
		id,
	)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{
			"error": "Failed to update book",
		})
		return
	}

	//if rows affected is 0, it means that ID does not exist
	rowsAffected, _ := result.RowsAffected()
	if rowsAffected == 0 {
		c.JSON(http.StatusNotFound, gin.H{
			"error": "Book not found",
		})
		return
	}

	err = db.QueryRow(`
		SELECT id, title, author, isbn, price, stock, published_year, description, created_at
		FROM books
		WHERE id = ?
	`, id).Scan(
		&book.ID,
		&book.Title,
		&book.Author,
		&book.ISBN,
		&book.Price,
		&book.Stock,
		&book.PublishedYear,
		&book.Description,
		&book.CreatedAt,
	)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{
			"error": "Failed to fetch updated book",
		})
		return
	}

	c.JSON(http.StatusOK, book)
}

func deleteBook(c *gin.Context) {
	id := c.Param("id")

	result, err := db.Exec("DELETE FROM books WHERE id = ?", id)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{
			"error": "Failed to delete book",
		})
		return
	}

	rowsAffected, _ := result.RowsAffected()
	if rowsAffected == 0 {
		c.JSON(http.StatusNotFound, gin.H{
			"error": "Book not found",
		})
		return
	}

	c.JSON(http.StatusOK, gin.H{
		"message": "Book deleted successfully",
	})
}

func main() {
	if err := initDB(); err != nil {
		log.Fatal("Failed to initialize database:", err)
	}
	defer db.Close()

	seedData()

	router := gin.Default()

	router.GET("/books", getBooks)
	router.GET("/books/:id", getBook)
	router.POST("/books", createBook)
	router.PUT("/books/:id", updateBook)
	router.DELETE("/books/:id", deleteBook)

	log.Println("Server starting on :8080")
	if err := router.Run(":8080"); err != nil {
		log.Fatal(err)
	}
}