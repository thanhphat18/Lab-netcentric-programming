package main

import (
	"database/sql"
	"log"
	"net/http"
	"strings"

	"github.com/gin-gonic/gin"
	_ "github.com/mattn/go-sqlite3"
)

type Book struct {
	ID            int     `json:"id"`
	Title         string  `json:"title" binding:"required"`
	Author        string  `json:"author" binding:"required"`
	ISBN          string  `json:"isbn"`
	Price         float64 `json:"price" binding:"required,gt=0"`
	Stock         int     `json:"stock" binding:"gte=0"`
	PublishedYear int     `json:"published_year"`
	Description   string  `json:"description"`
	CreatedAt     string  `json:"created_at"`
}

var db *sql.DB

func initDB() error {
	var err error
	db, err = sql.Open("sqlite3", "./bookstore.db")
	if err != nil {
		return err
	}

	createTableSQL := `
	CREATE TABLE IF NOT EXISTS books (
		id INTEGER PRIMARY KEY AUTOINCREMENT,
		title TEXT NOT NULL,
		author TEXT NOT NULL,
		isbn TEXT UNIQUE,
		price REAL NOT NULL CHECK(price > 0),
		stock INTEGER DEFAULT 0,
		published_year INTEGER,
		description TEXT,
		created_at DATETIME DEFAULT CURRENT_TIMESTAMP
	);`

	_, err = db.Exec(createTableSQL)
	return err
}

func seedData() {
	var count int
	err := db.QueryRow("SELECT COUNT(*) FROM books").Scan(&count)
	if err != nil || count > 0 {
		return
	}

	books := []Book{
		{
			Title:         "The Go Programming Language",
			Author:        "Alan Donovan",
			ISBN:          "978-0134190440",
			Price:         39.99,
			Stock:         15,
			PublishedYear: 2015,
			Description:   "Complete guide to Go",
		},
		{
			Title:         "Clean Code",
			Author:        "Robert Martin",
			ISBN:          "978-0132350884",
			Price:         42.50,
			Stock:         20,
			PublishedYear: 2008,
			Description:   "Handbook of Agile Software Craftsmanship",
		},
		{
			Title:         "Design Patterns",
			Author:        "Gang of Four",
			ISBN:          "978-0201633610",
			Price:         54.99,
			Stock:         8,
			PublishedYear: 1994,
			Description:   "Elements of Reusable Object-Oriented Software",
		},
		{
			Title:         "The Pragmatic Programmer",
			Author:        "Andrew Hunt",
			ISBN:          "978-0135957059",
			Price:         47.99,
			Stock:         12,
			PublishedYear: 2019,
			Description:   "Journey to mastery",
		},
		{
			Title:         "Code Complete",
			Author:        "Steve McConnell",
			ISBN:          "978-0735619678",
			Price:         49.99,
			Stock:         10,
			PublishedYear: 2004,
			Description:   "Practical handbook of software construction",
		},
		{
			Title:         "Learning Go",
			Author:        "Jon Bodner",
			ISBN:          "978-1492077213",
			Price:         44.99,
			Stock:         14,
			PublishedYear: 2021,
			Description:   "Idiomatic Go for real-world programming",
		},
	}

	for _, book := range books {
		_, err := db.Exec(
			`INSERT INTO books (title, author, isbn, price, stock, published_year, description)
			 VALUES (?, ?, ?, ?, ?, ?, ?)`,
			book.Title,
			book.Author,
			book.ISBN,
			book.Price,
			book.Stock,
			book.PublishedYear,
			book.Description,
		)
		if err != nil {
			log.Printf("warning: failed to seed %q: %v", book.Title, err)
		}
	}
}

func scanBooks(rows *sql.Rows) ([]Book, error) {
	defer rows.Close()

	books := []Book{}
	for rows.Next() {
		var book Book
		err := rows.Scan(
			&book.ID,
			&book.Title,
			&book.Author,
			&book.ISBN,
			&book.Price,
			&book.Stock,
			&book.PublishedYear,
			&book.Description,
			&book.CreatedAt,
		)
		if err != nil {
			return nil, err
		}
		books = append(books, book)
	}

	return books, nil
}

// GET /books
// Supports sorting + combined filters
func getBooks(c *gin.Context) {
	sortBy := c.DefaultQuery("sort", "id")
	minPrice := c.Query("min_price")
	maxPrice := c.Query("max_price")
	year := c.Query("year")
	author := c.Query("author")

	validSorts := map[string]string{
		"price_asc":  "price ASC",
		"price_desc": "price DESC",
		"title":      "title ASC",
		"year_desc":  "published_year DESC",
		"id":         "id ASC",
	}

	orderBy, ok := validSorts[sortBy]
	if !ok {
		orderBy = "id ASC"
	}

	queryBuilder := `
		SELECT id, title, author, isbn, price, stock, published_year, description, created_at
		FROM books
		WHERE 1=1
	`
	args := []interface{}{}

	if minPrice != "" {
		queryBuilder += " AND price >= ?"
		args = append(args, minPrice)
	}
	if maxPrice != "" {
		queryBuilder += " AND price <= ?"
		args = append(args, maxPrice)
	}
	if year != "" {
		queryBuilder += " AND published_year = ?"
		args = append(args, year)
	}
	if author != "" {
		queryBuilder += " AND LOWER(author) LIKE ?"
		args = append(args, "%"+strings.ToLower(author)+"%")
	}

	queryBuilder += " ORDER BY " + orderBy

	rows, err := db.Query(queryBuilder, args...)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{
			"error": "Failed to fetch books",
		})
		return
	}

	books, err := scanBooks(rows)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{
			"error": "Failed to read book data",
		})
		return
	}

	c.JSON(http.StatusOK, gin.H{
		"books": books,
		"count": len(books),
		"filters": gin.H{
			"min_price": minPrice,
			"max_price": maxPrice,
			"year":      year,
			"author":    author,
			"sort":      sortBy,
		},
	})
}

// GET /books/:id
func getBook(c *gin.Context) {
	id := c.Param("id")

	var book Book
	err := db.QueryRow(`
		SELECT id, title, author, isbn, price, stock, published_year, description, created_at
		FROM books
		WHERE id = ?
	`, id).Scan(
		&book.ID,
		&book.Title,
		&book.Author,
		&book.ISBN,
		&book.Price,
		&book.Stock,
		&book.PublishedYear,
		&book.Description,
		&book.CreatedAt,
	)

	if err == sql.ErrNoRows {
		c.JSON(http.StatusNotFound, gin.H{
			"error": "Book not found",
		})
		return
	}
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{
			"error": "Database error",
		})
		return
	}

	c.JSON(http.StatusOK, book)
}

// GET /books/search?q=go
func searchBooks(c *gin.Context) {
	queryText := strings.TrimSpace(c.Query("q"))
	if queryText == "" {
		c.JSON(http.StatusBadRequest, gin.H{
			"error": "Search query required",
		})
		return
	}

	searchPattern := "%" + strings.ToLower(queryText) + "%"

	rows, err := db.Query(`
		SELECT id, title, author, isbn, price, stock, published_year, description, created_at
		FROM books
		WHERE LOWER(title) LIKE ? OR LOWER(author) LIKE ?
		ORDER BY id ASC
	`, searchPattern, searchPattern)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{
			"error": "Search failed",
		})
		return
	}

	books, err := scanBooks(rows)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{
			"error": "Failed to read search results",
		})
		return
	}

	c.JSON(http.StatusOK, gin.H{
		"books": books,
		"count": len(books),
		"query": queryText,
	})
}

// GET /books/filter?min_price=20&max_price=50&year=2021&author=Martin
func filterBooks(c *gin.Context) {
	minPrice := c.Query("min_price")
	maxPrice := c.Query("max_price")
	author := c.Query("author")
	year := c.Query("year")

	queryBuilder := `
		SELECT id, title, author, isbn, price, stock, published_year, description, created_at
		FROM books
		WHERE 1=1
	`
	args := []interface{}{}

	if minPrice != "" {
		queryBuilder += " AND price >= ?"
		args = append(args, minPrice)
	}
	if maxPrice != "" {
		queryBuilder += " AND price <= ?"
		args = append(args, maxPrice)
	}
	if year != "" {
		queryBuilder += " AND published_year = ?"
		args = append(args, year)
	}
	if author != "" {
		queryBuilder += " AND LOWER(author) LIKE ?"
		args = append(args, "%"+strings.ToLower(author)+"%")
	}

	queryBuilder += " ORDER BY id ASC"

	rows, err := db.Query(queryBuilder, args...)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{
			"error": "Filter query failed",
		})
		return
	}

	books, err := scanBooks(rows)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{
			"error": "Failed to read filtered books",
		})
		return
	}

	c.JSON(http.StatusOK, gin.H{
		"books": books,
		"count": len(books),
		"filters": gin.H{
			"min_price": minPrice,
			"max_price": maxPrice,
			"year":      year,
			"author":    author,
		},
	})
}

// POST /books
func createBook(c *gin.Context) {
	var book Book

	if err := c.ShouldBindJSON(&book); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{
			"error":   "Invalid request data",
			"details": err.Error(),
		})
		return
	}

	result, err := db.Exec(`
		INSERT INTO books (title, author, isbn, price, stock, published_year, description)
		VALUES (?, ?, ?, ?, ?, ?, ?)
	`,
		book.Title,
		book.Author,
		book.ISBN,
		book.Price,
		book.Stock,
		book.PublishedYear,
		book.Description,
	)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{
			"error": "Failed to create book",
		})
		return
	}

	id, _ := result.LastInsertId()
	book.ID = int(id)
	_ = db.QueryRow("SELECT created_at FROM books WHERE id = ?", id).Scan(&book.CreatedAt)

	c.JSON(http.StatusCreated, book)
}

// PUT /books/:id
func updateBook(c *gin.Context) {
	id := c.Param("id")

	var book Book
	if err := c.ShouldBindJSON(&book); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{
			"error":   "Invalid request data",
			"details": err.Error(),
		})
		return
	}

	result, err := db.Exec(`
		UPDATE books
		SET title = ?, author = ?, isbn = ?, price = ?, stock = ?, published_year = ?, description = ?
		WHERE id = ?
	`,
		book.Title,
		book.Author,
		book.ISBN,
		book.Price,
		book.Stock,
		book.PublishedYear,
		book.Description,
		id,
	)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{
			"error": "Failed to update book",
		})
		return
	}

	rowsAffected, _ := result.RowsAffected()
	if rowsAffected == 0 {
		c.JSON(http.StatusNotFound, gin.H{
			"error": "Book not found",
		})
		return
	}

	err = db.QueryRow(`
		SELECT id, title, author, isbn, price, stock, published_year, description, created_at
		FROM books
		WHERE id = ?
	`, id).Scan(
		&book.ID,
		&book.Title,
		&book.Author,
		&book.ISBN,
		&book.Price,
		&book.Stock,
		&book.PublishedYear,
		&book.Description,
		&book.CreatedAt,
	)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{
			"error": "Failed to fetch updated book",
		})
		return
	}

	c.JSON(http.StatusOK, book)
}

// DELETE /books/:id
func deleteBook(c *gin.Context) {
	id := c.Param("id")

	result, err := db.Exec("DELETE FROM books WHERE id = ?", id)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{
			"error": "Failed to delete book",
		})
		return
	}

	rowsAffected, _ := result.RowsAffected()
	if rowsAffected == 0 {
		c.JSON(http.StatusNotFound, gin.H{
			"error": "Book not found",
		})
		return
	}

	c.JSON(http.StatusOK, gin.H{
		"message": "Book deleted successfully",
	})
}

func main() {
	if err := initDB(); err != nil {
		log.Fatal("Failed to initialize database:", err)
	}
	defer db.Close()

	seedData()

	router := gin.Default()

	// Put static routes before /books/:id
	router.GET("/books/search", searchBooks)
	router.GET("/books/filter", filterBooks)

	router.GET("/books", getBooks)
	router.GET("/books/:id", getBook)
	router.POST("/books", createBook)
	router.PUT("/books/:id", updateBook)
	router.DELETE("/books/:id", deleteBook)

	log.Println("Server starting on :8080")
	if err := router.Run(":8080"); err != nil {
		log.Fatal(err)
	}
}