module task4

go 1.25.0

require github.com/gorilla/websocket v1.5.3 // indirect
